from random import randint

def guessGame():
    currentGuess = randint(1, 100)
    guessed = False
    lower = 1
    upper = 100
    while guessed == False:
        print('is your number', currentGuess, '?')
        inpta = input('(y/n)')
        if inpta.lower() == 'n':
            inptb = input('lower? (y/n)')
            if inptb.lower() == 'y':
                upper = currentGuess
                currentGuess = int(((upper-lower)/2)+lower)
            elif inptb.lower() == 'n':
                lower = currentGuess
                currentGuess = int(((upper-lower)/2)+lower)
            else:
                print("invalid character, let's try again")
        elif inpta.lower() == 'y':
            print("Great, I won! let's try again some other time")
            print('Bye!')
            guessed = True
        else:
            print("invalid character, let's try again")

guessGame()